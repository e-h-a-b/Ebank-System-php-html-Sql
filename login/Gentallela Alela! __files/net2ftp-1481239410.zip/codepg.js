function convert(degree) {
   degree=c.value
		if (degree=="P1"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project1.php";}
		if (degree=="P2"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project2.php";}
		if (degree=="P3"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project3.php";}
		if (degree=="P4"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project4.php";}
		if (degree=="P5"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project5.php";}
		if (degree=="P6"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project6.php";}
		if (degree=="P7"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project7.php";}
		if (degree=="P8"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project8.php";}
		if (degree=="P9"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project9.php";}
		if (degree=="Pr10"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project10.php";}
		if (degree=="Pr11"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project11.php";}
		if (degree=="Pr12"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project12.php";}
		if (degree=="Pr13"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project13.php";}
		if (degree=="Pr14"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project14.php";}
		if (degree=="Pr15"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project15.php";}
		if (degree=="Pr16"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/project16.php";}
		if (degree=="L17"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P1.php";}
		if (degree=="L18"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P2.php";}
		if (degree=="L19"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P3.php";}
		if (degree=="L20"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P4.php";}
		if (degree=="L21"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P5.php";}
		if (degree=="L22"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P6.php";}
		if (degree=="L23"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P7.php";}
		if (degree=="L24"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P8.php";}
		if (degree=="L25"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P9.php";}
		if (degree=="L26"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P10.php";}
		if (degree=="L27"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P11.php";}
		if (degree=="L28"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P12.php";}
		if (degree=="L29"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P13.php";}
		if (degree=="L30"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P14.php";}
		if (degree=="L31"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/P15.php";}
		if (degree=="N32"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/n.php";}
		if (degree=="N33"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/profile.php";}
		if (degree=="N34"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login//allproject.php";}
		if (degree=="N35"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/price.php";}
		if (degree=="N36"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/inbox.php";}
		if (degree=="N37"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/logout.php";}
		if (degree=="N38"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/login/yourinfo.php";}
		if (degree=="N39"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/pm/list_pm.php";}
		if (degree=="N40"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/pm/index.php";}
		if (degree=="N41"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/pm/new_pm.php";}
		if (degree=="N42"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/pm/read_pm.php";}
		if (degree=="N43"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/pm/edit_infos.php";}
		if (degree=="N44"){document.getElementById("f").value = "1";document.getElementById("c").value = "";location.href = "http://ebank.esy.es/pm/users.php";}
		
}